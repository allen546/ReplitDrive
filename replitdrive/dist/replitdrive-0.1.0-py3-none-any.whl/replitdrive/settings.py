# Settings
import os

DEFAULT_MEDIA_DIRECTORY = os.path.join(os.getcwd(), "replitdrive/static/")