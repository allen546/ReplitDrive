# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['replitdrive']

package_data = \
{'': ['*'], 'replitdrive': ['static/css/*', 'templates/*']}

install_requires = \
['Flask>=2.2.2,<3.0.0', 'pycryptodomex>=3.15.0,<4.0.0', 'uWSGI>=2.0.20,<3.0.0']

setup_kwargs = {
    'name': 'replitdrive',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Allen Sun',
    'author_email': 'allen.haha@hotmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
