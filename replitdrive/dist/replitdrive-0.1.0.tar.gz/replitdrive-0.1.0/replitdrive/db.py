import sqlite3
from settings import *

class Database():
    def __init__(self, filename):
        self.db = sqlite3.connect(filename)
        self.cursor = self.db.cursor()
    pass

DATABASE = Database(os.path.join(DEFAULT_MEDIA_DIRECTORY, "db.sqlite3"))