from server import app

app.debug = True
app.run()